var app = angular.module('myApp', ['ngGrid']);
app.controller('MyCtrl', function($scope) {
    $scope.myData = [{EmployeeName: "Sam", age: 22},
                     {EmployeeName: "google", age: 24},
                     {EmployeeName: "Yahoo", age: 28},
                     {EmployeeName: "Bing", age: 27},
                     {EmployeeName: "Ram", age: 26 },
					 {EmployeeName: "Ganesan", age: 25},
					 {EmployeeName: "Test7", age: 22},
					];
    $scope.gridOptions = { data: 'myData' };
});